package com.samples.advancedjava.threads;

public class SMSThreadTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("main method.." + 
				Thread.currentThread().getName());
		MailThread mt = new MailThread(100);
		mt.setPriority(10);
		mt.setName("Mail Thread");
		
		MailThread mt1 = new MailThread(200);
		mt1.setPriority(5);
		mt1.setName("Mail Thread1");
		
		SMSThread st = new SMSThread(100);
		st.setPriority(5);
		st.setName("SMS Thread");
		
		SMSThread st1 = new SMSThread(200);
		st1.setPriority(10);
		st1.setName("SMS Thread1");
		
		//to start a thread, call start() method..
		//start() method, will internally call run()
		//method
		
		mt.start();
		mt1.start();
		st.start();
		st1.start();
		
		//If you want to make sure main thread
		//should be completed after completion of
		//all your threads, then you need to use join
		
		try {
			mt.join(); // join to parent thread.
			//in our case, it is main thread
			mt1.join();
			st.join();
			st1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		//BL can be written after completion of
		//all child threads..
		
		System.out.println("completed.."+ 
				Thread.currentThread().getName());
	}

}
