package com.samples.advancedjava.threads;

public class Message {

	private String message;
	
	private String obj = new String();
	public void produce(String message){		
		synchronized (this) {
			if(message!=null){
				this.message = message;
			//	notify();
			}
		}
	}
	
	public void consume(){
		synchronized (this) {
			if(message==null){
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(message);
		}
	}
}
