package com.samples.advancedjava.threads;

public class WithdrawThread extends Thread{

	private BankAccount bankAccount;
	
	public WithdrawThread(BankAccount bankAccount) {
		this.bankAccount = bankAccount;
	}
	
	public void run(){
		System.out.println("in WithdrawThread run");
		bankAccount.withdraw(500);
		System.out.println("WithdrawThread run completes");
	}
}
