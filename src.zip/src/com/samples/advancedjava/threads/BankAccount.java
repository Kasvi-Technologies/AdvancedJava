package com.samples.advancedjava.threads;

public class BankAccount {

	private int amount;
	
	public BankAccount(int amount){
		this.amount = amount;
	}
	
	public synchronized void deposit(int amount) {
		System.out.println("Inside depoist start:" 
						+ this.amount);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.amount = this.amount + amount;
		
		if (this.amount >=2000){
			System.out.println("notifying..");
			notifyAll();
		}
		
		System.out.println("Inside depoist ends:" 
						+ this.amount);		
	}
	
	public synchronized void withdraw(int amount) {
		System.out.println("Inside withdraw start:" 
				+ this.amount);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (this.amount <= 2000){
			try {
				System.out.println("waiting state..");
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		this.amount = this.amount - amount;
		System.out.println("Inside withdraw end:" 
				+ this.amount);		
	}
}
