package com.samples.advancedjava.threads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

class SimpleTHreadFactory implements ThreadFactory {

	@Override
	public Thread newThread(Runnable arg0) {
		// TODO Auto-generated method stub
		Thread t = new Thread(arg0);
		t.setName("My Thread");
		return t;
	}

	
}

public class MemoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Executors.newScheduledThreadPool(10, new SimpleTHreadFactory());
		List<Employee> empList = 
				new ArrayList<Employee>();
		
		for (int i = 0; i<100000;i++) {
			System.out.println("adding employee " +i);
			Employee emp = new Employee(i , "name " +i);
			empList.add(emp);
		}
		
		try {
			Thread.sleep(100000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
