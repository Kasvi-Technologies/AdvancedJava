package com.samples.advancedjava.threads;

import java.io.Serializable;

//Marker Interface -> which will not have any methods
//just a hint to JVM that this class can be serializable

//To persist state of an object, you need to make sure 
//implements Serializable interface

public class Employee implements Serializable , Comparable<Employee>{
	
	@Override
	public int compareTo(Employee emp) {
		// TODO Auto-generated method stub
		if(this.getId() > emp.getId()) {
			return 1;
		} else if (this.getId() < emp.getId()){
			return -1;
		} else{
			return 0;
		}
	}

	//static or transient -> 
	//if a variable is static or transient, it will not 
	// get persisted into file system
	
	//
	
	private static final long serialVersionUID = 1L;
	
	//serialVersionUID will make sure desrializaton happens 
	//properly eventhough class meta data 
	//added new variables or methods
	
	private double salary;
	
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Employee (int id, String name){
		this.id = id;
		this.name = name;
	}
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String name;

	
	
}
