package com.samples.advancedjava.threads;

public class BankAccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Here bankAccount is a Common resource
		//which is shared to multiple threads
		
		BankAccount bankAccount = 
						new BankAccount(1000);
		
		WithdrawThread wt = 
					new WithdrawThread(bankAccount);
		
		DepositThread dt = 
				new DepositThread(bankAccount);
		
		wt.start();
		dt.start();
	
	}

}
