package com.samples.advancedjava.threads;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class CallableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Callable<Integer> c = new Callable<Integer>()
		{
			public Integer call(){
				System.out.println("In callable ");
				return 100;
			}			
		};
		
		ExecutorService service = 
				Executors.newFixedThreadPool(5);
		
		Future<Integer> f = service.submit(c);
		try {
			System.out.println(f.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ExecutorService service1 = 
				Executors.newFixedThreadPool(5);		
		for (int i= 1; i<=10; i++){
			Runnable r = new Runnable(){
				public void run(){
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("inside for" 
							+Thread.currentThread().getName());
				}
			};			
			service1.execute(r);
		}
		
		//How to use JDK 1.8 Lambda expressions
		
		//Lambda expression is a combination of
		//Anonymous inner classes and Functional 
		//interfaces
		
		//Functional interfaces -> an interface which
		//have only one method
		
		Runnable r = new Runnable(){
			public void run(){
				System.out.println("inside for" 
						+Thread.currentThread().getName());
			}
		};			
		
		//The same you can write using jdk 1.8 
		//lambda expressions
		
		Runnable r1 = () -> {
			System.out.println("using lambda expression" 
					+Thread.currentThread().getName());
		};
		service.submit(r1);
		
		Callable<Integer> c1 = () -> {
			System.out.println("In callable");
			return 200;
		};
		
		Future<Integer> f2 = service.submit(c1);
		try {
			System.out.println(f2.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Scheduling a thread
		// Thread Schedulors
		ScheduledExecutorService sService= 
				Executors.newScheduledThreadPool(10);
		
		//first parameter is task which needs to be 
		//executed
		//second parameter specifier delay to start your task
		//third parameter spicies seconds, minutes or hours
		System.out.println("before executing task.");
		sService.schedule(c1, 10, TimeUnit.SECONDS);
		
		//Recurring Schedulers
		//Task
		//Inital delay
		//Recurring time, here i specifed 3
		//means every 3 minutes this job will executes
		//seconds minutes or hours
		Runnable r2 = () ->{
			System.out.println("recurring scheduler");
		};
		
		sService.scheduleAtFixedRate(r2, 
							2, 3, TimeUnit.SECONDS);
		
		Runnable r5 = () -> {
			sService.shutdown();
		};
		
		sService.schedule(r5, 30, TimeUnit.SECONDS);
	}
}
