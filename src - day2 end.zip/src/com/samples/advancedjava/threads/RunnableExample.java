package com.samples.advancedjava.threads;

public class RunnableExample implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Using Runnable interfaces");
	}
	
	public static void main (String args[]) {
		RunnableExample runnableExample = new
				RunnableExample();
	
		Thread t = new Thread(runnableExample);
		t.start();
		
	}

}
