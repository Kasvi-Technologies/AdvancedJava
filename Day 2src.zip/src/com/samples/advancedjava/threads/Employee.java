package com.samples.advancedjava.threads;

import java.io.Serializable;

//Marker Interface -> which will not have any methods
//just a hint to JVM that this class can be serializable

//To persist state of an object, you need to make sure 
//implements Serializable interface

public class Employee implements Serializable{

	
	public Employee (int id, String name){
		this.id = id;
		this.name = name;
	}
	
	private int id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	private String name;
	
}
