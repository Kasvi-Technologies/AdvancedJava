package com.samples.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.samples.advancedjava.threads.BankAccount;

public class ReflectionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Creating an instance using reflection
		
		try {
			Class bankAccountClass = 
					Class.forName("com.samples.advancedjava.threads.BankAccount");
						
			BankAccount ba = (BankAccount)
					bankAccountClass.newInstance();
			
			ba.deposit(1000);
			
			//Get all the fields
			Field fields[] = 
					bankAccountClass.getDeclaredFields();
			System.out.println("get All fields");
			for (Field f : fields){
				System.out.println(f.getName() 
						+ " " + f.getType() );
			}
			
			try {
				Field f1 = 
						bankAccountClass.getDeclaredField("amount");
				f1.setAccessible(true);
				
				System.out.println(f1.getName());
			} catch (NoSuchFieldException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//get all the methods
			System.out.println("get all methods..");
			Method methods [] = 
					bankAccountClass.getMethods();
			for (Method m : methods){
				System.out.println(m.getName());
				
			}
			
			Method m = 
					bankAccountClass.
					getDeclaredMethod("deposit", 
					new Class[]{Integer.TYPE});
			m.setAccessible(true);
			
			System.out.println("before invoking");
			m.invoke(ba, new Object[]{100});
			System.out.println("After invoking");
			m.getReturnType();
			m.getParameterTypes();
			m.getName();
			
			
			Method m1 = 
					bankAccountClass.
					getDeclaredMethod("sample", 
					new Class[]{String.class});
			m1.setAccessible(true);
			
			System.out.println("before invoking private method");
			m1.invoke(ba, new Object[]{"Hi"});
			System.out.println("After invoking");
			m1.getReturnType();
			m1.getParameterTypes();
			m1.getName();
			
			//BankAccount ba1 = new BankAccount(100);
			Constructor c1 = 
					bankAccountClass
					.getDeclaredConstructor(
					new Class[]{Integer.TYPE});
			System.out.println("calling parameterized");
			BankAccount ba1 = 
					(BankAccount) 
					c1.newInstance(new Object[]{100});
			
			
			//get all constructors
			Constructor con [] = 
					bankAccountClass.getConstructors();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
