package com.samples.advancedjava.threads;

//java.lang.Thread
public class SMSThread extends Thread{

	public SMSThread(int accountId){
		this.accountId = accountId;
	}
	private int accountId;
	
	public void run() {
		System.out.println("Business logic to "
				+ "send SMS in SMS Thread");
		//BL
		for (int i = 0;i<5;i++){
			System.out.println(Thread.currentThread()
					.getName() + 
						" " + i
						+ " for account id " +accountId);
			
			try {
				Thread.sleep(1000); //mill seconds
				//i.e 1 sec
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
