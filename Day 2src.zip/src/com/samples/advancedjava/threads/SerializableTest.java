package com.samples.advancedjava.threads;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class SerializableTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Employee emp = new Employee(10, "sadas");
		
		File f = new File("C:\\emp.ser");
		try {
			FileOutputStream fout = new FileOutputStream(f);
			//To write objects
			
			ObjectOutputStream oOut = new ObjectOutputStream(fout);
			
			oOut.writeObject(emp);
			System.out.println("Done..... emp object serialized");
//			
			
			//Read the object from File System
			//Deserializaton
			FileInputStream fIn = new FileInputStream(f);
			ObjectInputStream oIn = new ObjectInputStream(fIn);
			Employee emp1 = (Employee) oIn.readObject();
			System.out.println(emp1.getId() + " " + emp1.getName());
			
			System.out.println("Desrialiation done...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
