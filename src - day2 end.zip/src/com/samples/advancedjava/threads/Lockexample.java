package com.samples.advancedjava.threads;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Lockexample extends Thread {

	//Lock is an interface
	//ReentrantLock is an implementation of Lock
	private Lock lock = new ReentrantLock();

	public void deposit() throws Exception{
		//
		//
		//it will wait for 100 seconds to obtain the 
		//lock
		//if it is unable to obtain the lock within
		//100 seconds, return the boolean flag
		//Ths feature is not possible with
		//synchronization
		try {
			boolean flag = 
					lock.tryLock(100, TimeUnit.SECONDS);
			//true means obtained the lock
			
			//false means unable to obtain the lock
			//with in specified time
			if (flag == true) {
				
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			throw e;
		}
		
		///
//		///
//		
//		lock.unlock();
	}
	
	public void withdraw(){
		lock.lock();
		
		
		
		lock.unlock();
	}
	public void run(){
		sum(10,15);
	}
	public int sum (int a , int b){
		lock.lock();
		int sum = a+b;
		System.out.println("in sum method..");		
		method1();		
		return sum;
	}
	
	public void method1(){
		System.out.println("Busness logic");
		lock.unlock();  //not possible with Synchro
		System.out.println("other businneslogic");
	}
	//ReadWriteLock rwl = 
			//new ReentrantReadWriteLock();
	
	//Thread1 read() Thread2 read() -> allowed
	//Thread1 write() thread2 write() -> not allowed
	//Thread1 write() thread2 read () -> not allowed
	public void method5(ReadWriteLock rwl){
		rwl.readLock().lock();
		//bl
		rwl.readLock().unlock();
	}
	
	public void method6(ReadWriteLock rwl){
		rwl.writeLock().lock();
		//bl
		rwl.writeLock().unlock();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lockexample lockEx = new Lockexample();
		lockEx.start();
		
		//ReadWriteLock is an interface
		//ReentrantReadWriteLock is an implementation
		
		//multiple threads can access the readlock
		//at the same time if writelock was not 
		//obtained any lock
		
		
		
		
		
		
	}

}
