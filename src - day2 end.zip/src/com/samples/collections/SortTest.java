package com.samples.collections;

import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

import com.samples.advancedjava.threads.Employee;

public class SortTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//List, Set and Map
		
		//TreeSet is responsible for sorting
		
		Set<Employee> empSet = new TreeSet<Employee>();
		
		Employee emp1 = new Employee(500, "sadad");
		Employee emp2 = new Employee(800, "ytut");
		Employee emp3 = new Employee(100, "qwewqe");
		Employee emp4 = new Employee(200, "gfnhg");
		Employee emp5 = new Employee(600, "anmnmn");		
		
		empSet.add(emp1);
		empSet.add(emp2);
		empSet.add(emp3);
		empSet.add(emp4);
		empSet.add(emp5);
		
		System.out.println("Display employees with default Sorting");

		Iterator<Employee> empSetItr = empSet.iterator();
		while(empSetItr.hasNext()){
			Employee emp = empSetItr.next();
			System.out.println(emp.getId() + " " + emp.getName());
		}
		
		Set<Employee> empSet1 = new TreeSet<Employee>(
				new EmployeeNameComparator());
		
		empSet1.add(emp1);
		empSet1.add(emp2);
		empSet1.add(emp3);
		empSet1.add(emp4);
		empSet1.add(emp5);
		
		System.out.println("Display employees with name based Sorting");

		Iterator<Employee> empSetItr1 = empSet1.iterator();
		while(empSetItr1.hasNext()){
			Employee emp = empSetItr1.next();
			System.out.println(emp.getId() + " " + emp.getName());
		}

	}
}

class EmployeeNameComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee emp1, Employee emp2) {
		// TODO Auto-generated method stub
		if(emp1.getName().compareTo(emp2.getName())>1) {
			return 1;
		} else if (emp1.getName().compareTo(emp2.getName())<1){
			return -1;
		} else{
			return 0;
		}
	}
	
}




