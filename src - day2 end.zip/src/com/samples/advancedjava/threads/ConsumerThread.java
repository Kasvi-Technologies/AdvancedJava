package com.samples.advancedjava.threads;

public class ConsumerThread extends Thread{
	private Message message;
	
	public ConsumerThread(Message message){
		this.message = message;
	}
	public void run(){
		message.consume();;
	}
}
