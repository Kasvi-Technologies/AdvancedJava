package com.samples.advancedjava.threads;

class Method1Thread extends Thread {
	private Deadlockexample deadlockexample;
	public Method1Thread(Deadlockexample deadlockexample){
		this.deadlockexample = deadlockexample;
	}
	public void run(){
		deadlockexample.method1();
	}
}

class Method2Thread extends Thread {
	private Deadlockexample deadlockexample;
	public Method2Thread(Deadlockexample deadlockexample){
		this.deadlockexample = deadlockexample;
	}
	public void run(){
		deadlockexample.method2();
	}
}

public class Deadlockexample {
	
	public static void main(String args[]){
		Deadlockexample deadlockexample = 
						new Deadlockexample();
		Method1Thread method1Thread = 
						new Method1Thread(deadlockexample);
		
		Method2Thread method2Thread = 
				new Method2Thread(deadlockexample);
		method1Thread.start();
		method2Thread.start();
	}

	private String str1 = "Hi";
	private String str2 = "Hello";
	
	public void method1(){
		synchronized (str1){
			System.out.println("Obtained method1 "
					+ "lock on str1");
			synchronized(str2){
				System.out.println("Obtained method1"
						+ " lock on str2");
			}
		}
	}	
	public void method2(){
		synchronized (str2){
			System.out.println("Obtained method2 "
					+ "lock on str2");
			synchronized(str1){
				System.out.println("Obtained method2 "
						+ "lock on str1");
			}
		}
	}

}
