package com.samples.advancedjava.threads;

public class ReentrantEx implements Runnable {

	public void run(){
		method1();
	}
	public synchronized void method1(){
		System.out.println("in method1");
		method2();
	}
	
	public synchronized void method2(){
		System.out.println("in method2");
	}
	public static void main(String[] args) {
		Thread t = new Thread(new ReentrantEx());
		t.start();
	}

}
