package com.samples.advancedjava.threads;

//ThredLocal will create seperate variables 
//for each thread
//so that each thread will have its own local copy

public class ThreadLocalExample extends Thread{

	private ThreadLocal<Integer> tLocalInt = 
			new ThreadLocal<Integer>();
	
	public void run(){
		method1();
	}
	public void method1(){
		tLocalInt.set(100);
		
		System.out.println(tLocalInt.get());
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	}

}
