package com.samples.advancedjava.threads;

public class MailThreadTest {

	public static void main(String[] args) {
		MailThread mt = new MailThread(100);
		MailThread mt1 = new MailThread(200);
		MailThread mt2 = new MailThread(300);
		MailThread mt3 = new MailThread(600);
		MailThread mt4 = new MailThread(500);
		
		//to start a thread, call start() method..
		//start() method, will internally call run()
		//method
		
		mt.start();
		mt1.start();
		mt2.start();
		mt3.start();
		mt4.start();
		
	}

}
