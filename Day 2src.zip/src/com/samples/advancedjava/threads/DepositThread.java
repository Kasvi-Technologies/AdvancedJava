package com.samples.advancedjava.threads;

public class DepositThread extends Thread{

	private BankAccount bankAccount;
	
	public DepositThread(BankAccount bankAccount){
		this.bankAccount = bankAccount;
	}
	
	public void run(){
		System.out.println("in DepositThread run");
		bankAccount.deposit(1000);
		System.out.println("DepositThread run completes");
	}
}
