package com.samples.advancedjava.threads;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ExecutorServiceTest {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ExecutorService service = 
				Executors.newFixedThreadPool(5);
		
		Message message = new Message();
		ConsumerThread ct = 
				new ConsumerThread(message);
		ct.setName("Consumer Thread");
		ProducerThread pt = 
				new ProducerThread(message);
		pt.setName("Producer Thread");
		
		service.execute(ct);
		service.execute(pt);	
		
		//public class MyRunnable implements Runnable {
		//	public void run(){
				
		//	}
		//}
		
		Runnable myRunnable = new Runnable() {
			public void run(){
				System.out.println("myrunnable..");
			}
		};
		
		service.execute(myRunnable); 
		//Thread t = new Thread(myRunnable);
		//t.start();
		//execute method will not return anything
		
		Future f = service.submit(myRunnable);
		//execute and submit both are same but
		//submit will return Future Object
		//f.get() will get the return value
		//in case of runnable, it will return null
		
		try {
			System.out.println(f.get()); //displays null
			//runnable thread successfully  completed.
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MyCallable mycallable = new MyCallable();
		Future<String> f1 = 
				service.submit(mycallable);
		
		try {
			System.out.println(f1.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		service.shutdown();
		
		//execute method will internally call start
	}
}

//Callable interfaces are similar to Runnable interfaces
//But, callable interfaces can return the value 
//after completion 
class MyCallable implements Callable<String> {
	@Override
	public String call() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("inside callable call "
				+ "method");
		return "Success";
	}
	
}






