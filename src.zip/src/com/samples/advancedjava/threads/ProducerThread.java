package com.samples.advancedjava.threads;

public class ProducerThread extends Thread{

	private Message message;
	
	public ProducerThread(Message message){
		this.message = message;
	}
	public void run(){
		message.produce("Producer Message sent...");
	}
}
