public class WithOutThreads {

	public static void main(String[] args) {
		//2 independent Business Logic
		
		//1. first business logic
		for (int i = 0; i< 10; i++) {
			System.out.println("First Business Logic " + i);
			//Business logic
		}
		
		//2. Second business logic
		for (int j = 0; j< 10; j++) {
			System.out.println("Second Business Logic " + j);
			//Business Logic
		}
		
	}

}
