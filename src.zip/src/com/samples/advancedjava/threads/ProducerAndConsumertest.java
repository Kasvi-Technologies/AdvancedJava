package com.samples.advancedjava.threads;

public class ProducerAndConsumertest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Message message = new Message();
		ConsumerThread ct = 
				new ConsumerThread(message);
		ct.setName("Consumer Thread");
		ProducerThread pt = 
				new ProducerThread(message);
		pt.setName("Producer Thread");
		
		ct.start();
		pt.start();
	}

}
